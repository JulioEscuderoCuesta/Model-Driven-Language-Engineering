/**
 */
package flight_planner.impl;

import flight_planner.AdministrationOficine;
import flight_planner.Flight_plannerPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Administration Oficine</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class AdministrationOficineImpl extends InfrastructureImpl implements AdministrationOficine {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AdministrationOficineImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Flight_plannerPackage.Literals.ADMINISTRATION_OFICINE;
	}

} //AdministrationOficineImpl
