/**
 */
package flight_planner.impl;

import flight_planner.Flight_plannerPackage;
import flight_planner.MaintenanceHangar;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Maintenance Hangar</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MaintenanceHangarImpl extends InfrastructureImpl implements MaintenanceHangar {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MaintenanceHangarImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Flight_plannerPackage.Literals.MAINTENANCE_HANGAR;
	}

} //MaintenanceHangarImpl
