/**
 */
package candy_factory_v2.tests;

import junit.framework.Test;
import junit.framework.TestSuite;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>Candy_factory_v2</b></em>' model.
 * <!-- end-user-doc -->
 * @generated
 */
public class Candy_factory_v2AllTests extends TestSuite {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(suite());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Test suite() {
		TestSuite suite = new Candy_factory_v2AllTests("Candy_factory_v2 Tests");
		suite.addTest(Candy_factory_v2Tests.suite());
		return suite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Candy_factory_v2AllTests(String name) {
		super(name);
	}

} //Candy_factory_v2AllTests
