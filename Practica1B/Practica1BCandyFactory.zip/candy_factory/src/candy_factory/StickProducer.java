/**
 */
package candy_factory;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stick Producer</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory.Candy_factoryPackage#getStickProducer()
 * @model
 * @generated
 */
public interface StickProducer extends Producer {
} // StickProducer
