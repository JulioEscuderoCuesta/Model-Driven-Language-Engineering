/**
 */
package candy_factory;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Flattener</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory.Candy_factoryPackage#getFlattener()
 * @model
 * @generated
 */
public interface Flattener extends Machine {
} // Flattener
