/**
 */
package candy_factory;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lollipop</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory.Candy_factoryPackage#getLollipop()
 * @model
 * @generated
 */
public interface Lollipop extends Component {
} // Lollipop
