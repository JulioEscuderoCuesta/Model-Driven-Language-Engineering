/**
 */
package candy_factory;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Candy Ball</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory.Candy_factoryPackage#getCandyBall()
 * @model
 * @generated
 */
public interface CandyBall extends Component {
} // CandyBall
