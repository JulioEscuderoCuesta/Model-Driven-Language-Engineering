/**
 */
package candy_factory;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stick</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory.Candy_factoryPackage#getStick()
 * @model
 * @generated
 */
public interface Stick extends Component {
} // Stick
