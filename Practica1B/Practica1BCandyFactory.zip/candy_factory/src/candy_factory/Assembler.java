/**
 */
package candy_factory;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Assembler</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory.Candy_factoryPackage#getAssembler()
 * @model
 * @generated
 */
public interface Assembler extends Machine {
} // Assembler
