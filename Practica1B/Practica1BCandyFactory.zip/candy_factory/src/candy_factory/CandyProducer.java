/**
 */
package candy_factory;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Candy Producer</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory.Candy_factoryPackage#getCandyProducer()
 * @model
 * @generated
 */
public interface CandyProducer extends Producer {
} // CandyProducer
