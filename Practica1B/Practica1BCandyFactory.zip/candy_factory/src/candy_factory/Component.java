/**
 */
package candy_factory;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Component</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory.Candy_factoryPackage#getComponent()
 * @model abstract="true"
 * @generated
 */
public interface Component extends EObject {
} // Component
