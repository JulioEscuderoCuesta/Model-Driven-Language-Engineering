/**
 */
package candy_factory.impl;

import candy_factory.Candy_factoryPackage;
import candy_factory.Flattener;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Flattener</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FlattenerImpl extends MachineImpl implements Flattener {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FlattenerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Candy_factoryPackage.Literals.FLATTENER;
	}

} //FlattenerImpl
