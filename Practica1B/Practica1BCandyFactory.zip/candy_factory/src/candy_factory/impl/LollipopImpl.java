/**
 */
package candy_factory.impl;

import candy_factory.Candy_factoryPackage;
import candy_factory.Lollipop;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Lollipop</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LollipopImpl extends ComponentImpl implements Lollipop {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LollipopImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Candy_factoryPackage.Literals.LOLLIPOP;
	}

} //LollipopImpl
