/**
 */
package candy_factory.impl;

import candy_factory.CandyFlat;
import candy_factory.Candy_factoryPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Candy Flat</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class CandyFlatImpl extends ComponentImpl implements CandyFlat {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CandyFlatImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Candy_factoryPackage.Literals.CANDY_FLAT;
	}

} //CandyFlatImpl
