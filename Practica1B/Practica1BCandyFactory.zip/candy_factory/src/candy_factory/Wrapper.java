/**
 */
package candy_factory;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Wrapper</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory.Candy_factoryPackage#getWrapper()
 * @model
 * @generated
 */
public interface Wrapper extends Machine {
} // Wrapper
