/**
 */
package candy_factory_v2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Candy Ball</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory_v2.Candy_factory_v2Package#getCandyBall()
 * @model
 * @generated
 */
public interface CandyBall extends Component {
} // CandyBall
