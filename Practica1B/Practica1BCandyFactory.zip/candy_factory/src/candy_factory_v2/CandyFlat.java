/**
 */
package candy_factory_v2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Candy Flat</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory_v2.Candy_factory_v2Package#getCandyFlat()
 * @model
 * @generated
 */
public interface CandyFlat extends Component {
} // CandyFlat
