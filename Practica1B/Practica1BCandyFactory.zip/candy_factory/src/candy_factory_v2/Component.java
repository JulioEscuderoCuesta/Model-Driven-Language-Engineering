/**
 */
package candy_factory_v2;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Component</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory_v2.Candy_factory_v2Package#getComponent()
 * @model abstract="true"
 * @generated
 */
public interface Component extends EObject {
} // Component
