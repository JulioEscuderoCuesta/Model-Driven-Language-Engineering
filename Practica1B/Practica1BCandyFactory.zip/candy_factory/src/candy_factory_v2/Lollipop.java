/**
 */
package candy_factory_v2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lollipop</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory_v2.Candy_factory_v2Package#getLollipop()
 * @model
 * @generated
 */
public interface Lollipop extends Component {
} // Lollipop
