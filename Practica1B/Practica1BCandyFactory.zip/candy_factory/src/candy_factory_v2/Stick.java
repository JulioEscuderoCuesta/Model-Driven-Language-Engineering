/**
 */
package candy_factory_v2;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stick</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see candy_factory_v2.Candy_factory_v2Package#getStick()
 * @model
 * @generated
 */
public interface Stick extends Component {
} // Stick
