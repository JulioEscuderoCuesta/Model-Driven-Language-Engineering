/**
 */
package candy_factory_v2.impl;

import candy_factory_v2.CandyBall;
import candy_factory_v2.Candy_factory_v2Package;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Candy Ball</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class CandyBallImpl extends ComponentImpl implements CandyBall {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CandyBallImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Candy_factory_v2Package.Literals.CANDY_BALL;
	}

} //CandyBallImpl
