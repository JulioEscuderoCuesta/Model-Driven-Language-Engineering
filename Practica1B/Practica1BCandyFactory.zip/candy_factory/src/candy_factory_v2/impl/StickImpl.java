/**
 */
package candy_factory_v2.impl;

import candy_factory_v2.Candy_factory_v2Package;
import candy_factory_v2.Stick;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Stick</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class StickImpl extends ComponentImpl implements Stick {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StickImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Candy_factory_v2Package.Literals.STICK;
	}

} //StickImpl
