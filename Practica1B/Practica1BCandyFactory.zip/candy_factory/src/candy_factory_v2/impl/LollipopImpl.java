/**
 */
package candy_factory_v2.impl;

import candy_factory_v2.Candy_factory_v2Package;
import candy_factory_v2.Lollipop;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Lollipop</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LollipopImpl extends ComponentImpl implements Lollipop {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LollipopImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Candy_factory_v2Package.Literals.LOLLIPOP;
	}

} //LollipopImpl
