/**
 */
package flight_planner.impl;

import flight_planner.Flight_plannerPackage;
import flight_planner.NoBase;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>No Base</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class NoBaseImpl extends PlaceImpl implements NoBase {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NoBaseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Flight_plannerPackage.Literals.NO_BASE;
	}

} //NoBaseImpl
