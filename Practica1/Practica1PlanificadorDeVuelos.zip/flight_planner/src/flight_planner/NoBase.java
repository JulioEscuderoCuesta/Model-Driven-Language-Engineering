/**
 */
package flight_planner;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>No Base</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see flight_planner.Flight_plannerPackage#getNoBase()
 * @model
 * @generated
 */
public interface NoBase extends Place {
} // NoBase
