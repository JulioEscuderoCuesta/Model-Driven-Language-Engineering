/**
 */
package flight_planner;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Infrastructure</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see flight_planner.Flight_plannerPackage#getInfrastructure()
 * @model abstract="true"
 * @generated
 */
public interface Infrastructure extends EObject {
} // Infrastructure
