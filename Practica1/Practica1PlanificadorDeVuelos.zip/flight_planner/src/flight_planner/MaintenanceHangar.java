/**
 */
package flight_planner;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Maintenance Hangar</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see flight_planner.Flight_plannerPackage#getMaintenanceHangar()
 * @model
 * @generated
 */
public interface MaintenanceHangar extends Infrastructure {
} // MaintenanceHangar
