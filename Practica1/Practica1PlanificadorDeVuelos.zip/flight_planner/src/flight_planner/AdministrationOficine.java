/**
 */
package flight_planner;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Administration Oficine</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see flight_planner.Flight_plannerPackage#getAdministrationOficine()
 * @model
 * @generated
 */
public interface AdministrationOficine extends Infrastructure {
} // AdministrationOficine
